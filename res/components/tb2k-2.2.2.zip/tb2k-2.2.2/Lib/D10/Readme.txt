This directory will be populated when the tb2k_d10 package is compiled.
