Scintilla.iface generator.

IFGen was used to generate DScintilla*.inc files.
You don't need it to use DScintilla. Only in case of upgrade interface to newer version (you could also make it by hand).

Note: IFGen source code is a MESS BY DESIGN(tm)