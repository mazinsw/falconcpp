using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using chsDetIntf;

namespace dotNeTest {
	public class WinForm : System.Windows.Forms.Form {
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button btnRun;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.Button btnInfo;
		private System.Windows.Forms.Button btnAbout;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblCharsetInfo;

		public WinForm() {
			InitializeComponent();
			btnAbout_Click(null, null);
		}

		protected override void Dispose(bool disposing)	{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(WinForm));
			this.btnRun = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.btnInfo = new System.Windows.Forms.Button();
			this.btnAbout = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.lblCharsetInfo = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnRun
			// 
			this.btnRun.Location = new System.Drawing.Point(16, 8);
			this.btnRun.Name = "btnRun";
			this.btnRun.TabIndex = 0;
			this.btnRun.Text = "Detect...";
			this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "E:\\Projects\\chsdet\\Local\\testData\\932test.txt";
			// 
			// richTextBox1
			// 
			this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
						| System.Windows.Forms.AnchorStyles.Left) 
						| System.Windows.Forms.AnchorStyles.Right)));
			this.richTextBox1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.richTextBox1.Location = new System.Drawing.Point(4, 64);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(448, 296);
			this.richTextBox1.TabIndex = 2;
			this.richTextBox1.Text = "richTextBox1";
			this.richTextBox1.WordWrap = false;
			// 
			// btnInfo
			// 
			this.btnInfo.Location = new System.Drawing.Point(216, 10);
			this.btnInfo.Name = "btnInfo";
			this.btnInfo.TabIndex = 3;
			this.btnInfo.Text = "Info";
			this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
			// 
			// btnAbout
			// 
			this.btnAbout.Location = new System.Drawing.Point(336, 10);
			this.btnAbout.Name = "btnAbout";
			this.btnAbout.TabIndex = 4;
			this.btnAbout.Text = "About";
			this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(24, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 16);
			this.label1.TabIndex = 5;
			this.label1.Text = "Charset";
			// 
			// lblCharsetInfo
			// 
			this.lblCharsetInfo.Location = new System.Drawing.Point(80, 40);
			this.lblCharsetInfo.Name = "lblCharsetInfo";
			this.lblCharsetInfo.Size = new System.Drawing.Size(352, 16);
			this.lblCharsetInfo.TabIndex = 6;
			this.lblCharsetInfo.Text = "--";
			// 
			// WinForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(456, 365);
			this.Controls.Add(this.lblCharsetInfo);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnAbout);
			this.Controls.Add(this.btnInfo);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.btnRun);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "WinForm";
			this.Text = "Charset Detector Tester";
			this.ResumeLayout(false);
		}
		#endregion

		[STAThread]
		static void Main() {
			Application.Run(new WinForm());
		}

		private void btnRun_Click(object sender, System.EventArgs e) {
			if (openFileDialog1.ShowDialog() != DialogResult.OK) {
				return;
			}

			richTextBox1.ScrollBars = RichTextBoxScrollBars.Both;
			richTextBox1.WordWrap = false;

			System.IO.FileStream fs = System.IO.File.OpenRead(openFileDialog1.FileName);
			System.IO.BinaryReader br = new System.IO.BinaryReader(fs);

			int size = (int)fs.Length;
			if (size > 10000) {
			  size = 10000;
			}
			byte[] byteArray = br.ReadBytes(size);
			CharsetDetector.GuessEncoding(byteArray);
            	
			byteArray = null;
			br = null;
			fs = null;

			chsDetIntf.rCharsetInfo info;
			CharsetDetector.GetDetectedCharsetInfo(out info);

			lblCharsetInfo.Text = info.Name + " (" + info.CodePage.ToString() + ")";

			eBOMKind bom;
			bom = CharsetDetector.GetDetectedBOM();
			lblCharsetInfo.Text += " " + Enum.GetName(typeof(eBOMKind), bom);


			try {
				System.Text.Encoding encoding = System.Text.Encoding.GetEncoding(info.CodePage);

				System.IO.StreamReader sr = new System.IO.StreamReader(openFileDialog1.FileName, encoding);
				richTextBox1.Text = sr.ReadToEnd();
			} catch (Exception ex) {
				richTextBox1.Text = "Code page " + info.CodePage.ToString() + " for " + info.Name + " not found on this system!" + ex.Message;
			}

		}

		private void btnInfo_Click(object sender, System.EventArgs e) {
			richTextBox1.ScrollBars = RichTextBoxScrollBars.Both;
			richTextBox1.WordWrap = false;
			String knownCharsets;
			int l;
			l = CharsetDetector.GetKnownCharsets(out knownCharsets);
			richTextBox1.Text = knownCharsets;
		}

		private void btnAbout_Click(object sender, System.EventArgs e) {
			richTextBox1.ScrollBars = RichTextBoxScrollBars.None;
			richTextBox1.WordWrap = true;
			chsDetIntf.rAboutHolder about;
			CharsetDetector.GetAbout(out about);
			richTextBox1.Text =
				about.About +
				System.Environment.NewLine + System.Environment.NewLine +
				"Version " +
				about.MajorVersionNr.ToString() + "." +
				about.MinorVersionNr.ToString() + "." +
				about.BuildVersionNr.ToString() + "."
				;

		}
	}
}
