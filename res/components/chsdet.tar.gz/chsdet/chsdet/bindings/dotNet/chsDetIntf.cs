using System;
using System.Runtime.InteropServices;

namespace chsDetIntf
{
  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct rCharsetInfo {
	[MarshalAs(UnmanagedType.BStr)]
	public String Name;
	public Int32 CodePage;
	[MarshalAs(UnmanagedType.BStr)]
	public String Language;
  }

  [StructLayout(LayoutKind.Sequential, Pack = 1)]
  public struct rAboutHolder {
	public UInt32 MajorVersionNr;
	public UInt32 MinorVersionNr;
	public UInt32 BuildVersionNr;
	[MarshalAs(UnmanagedType.BStr)]
	public String About;
  }

  public enum eBOMKind : byte {
	BOM_Not_Found,
	BOM_UCS4_BE,    // 00 00 FE FF           UCS-4,    big-endian machine    (1234 order)
	BOM_UCS4_LE,    // FF FE 00 00           UCS-4,    little-endian machine (4321 order)
	BOM_UCS4_2143,  // 00 00 FF FE           UCS-4,    unusual octet order   (2143)
	BOM_UCS4_3412,  // FE FF 00 00           UCS-4,    unusual octet order   (3412)
	BOM_UTF16_BE,   // FE FF ## ##           UTF-16,   big-endian
	BOM_UTF16_LE,   // FF FE ## ##           UTF-16,   little-endian
	BOM_UTF8        // EF BB BF              UTF-8
  }

	public class CharsetDetector {
		private const int NS_OK = 0;

		public CharsetDetector() {
		}

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_Reset",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern void Reset();

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_HandleData",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern Int32 HandleData([In] IntPtr aBuf, Int32 aLen);

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_Done",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern Boolean Done();

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_DataEnd",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern void DataEnd();

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_GetDetectedCharsetInfo",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern void GetDetectedCharsetInfo([Out, MarshalAs(UnmanagedType.Struct)] out rCharsetInfo CharsetInfo);

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_GetKnownCharsets",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern Int32 GetKnownCharsets([Out, MarshalAs(UnmanagedType.BStr)] out String KnownCharsets);

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_GetAbout",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern void GetAbout([Out, MarshalAs(UnmanagedType.Struct)] out rAboutHolder About);

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_GetDetectedBOM",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern eBOMKind GetDetectedBOM();

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_DisableCharsetCP",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern Int32 DisableCharsetCP([In] Int32 CodePage);

		[DllImport(@"chsdet.dll", EntryPoint = "chsdet_GetBOMLength",
			  ExactSpelling = true,       // don't resolve A or W suffix
			  CallingConvention = CallingConvention.StdCall,
			  CharSet = CharSet.Unicode,
			  SetLastError = false, 		// don't call GetLastWin32Error to get error
			  PreserveSig = true    		// don't convert to safecall
		  )]
		public static extern Int32 GetBOMLength([In] eBOMKind BOM);


		public static void GuessEncoding(byte[] Data){
			Reset();
			unsafe {
				fixed (byte* p = Data) {
					IntPtr ptr = (IntPtr)p;
					HandleData(ptr, Data.Length);
				}
			}
			if (!Done()) {
			   DataEnd();
			}
		}
	}
}



