-----------Summary
Charset Detector - as the name says - is a stand alone executable module for automatic charset detection of a given text.
It can be useful for internationalisation support in multilingual applications such as web-script editors or Unicode editors.
Given input buffer will be analysed to guess used encoding. The result can be used as control parameter for charset conversation procedure.
Charset Detector can be compiled (and hopefully used) for MS Windows (as dll - dynamic link library), Linux or any other OS supported be Free Pascal.
Based on Mozilla's i18n component - http://www.mozilla.org/projects/intl/.

-----------State
Version 0.2.8 stable.
The latest version can be found at http://chsdet.sourceforge.net.

-----------Requirements
Charset Detector doesn't need any external components.

-----------Precompiled biaries and bindings 
You can download precompiled binaries for MS windows and Linux. 
Bindings avialable for Delphi (6 - XE), .NET and Lazarus.

-----------Output
As result you will get guessed charset as MS Windows Code Page id and charset name.

-----------Licence
Charset Detector is open source project and distributed under Lesser GPL.
See the GNU Lesser General Public License for more details - http://www.opensource.org/licenses/lgpl-license.php

-----------Supported charsets

 +-----------+---------------------------+------------------------+
 | Code pade |           Name            |      Note              |
 +-----------+---------------------------+------------------------+
 |      0    |  ASCII                    |   Pseudo code page.    |
 |    855    |  IBM855                   |                        |
 |    866    |  IBM866                   |                        |
 |    932    |  Shift_JIS                |                        |
 |    950    |  Big5                     |                        |
 |   1200    |  UTF-16LE                 |                        |
 |   1201    |  UTF-16BE                 |                        |
 |   1251    |  windows-1251             |                        |
 |   1252    |  windows-1252             |                        |
 |   1253    |  windows-1253             |                        |
 |   1255    |  windows-1255             |                        |
 |  10007    |  x-mac-cyrillic           |                        |
 |  12000    |  X-ISO-10646-UCS-4-2143   |                        |
 |  12000    |  UTF-32LE                 |                        |
 |  12001    |  X-ISO-10646-UCS-4-3412   |                        |
 |  12001    |  UTF-32BE                 |                        |
 |  20866    |  KOI8-R                   |                        |
 |  28595    |  ISO-8859-5               |                        |
 |  28595    |  ISO-8859-5               |                        |
 |  28597    |  ISO-8859-7               |                        |
 |  28598    |  ISO-8859-8               |                        |
 |  50222    |  ISO-2022-JP              |                        |
 |  50225    |  ISO-2022-KR              |                        |
 |  50227    |  ISO-2022-CN              |                        |
 |  51932    |  EUC-JP                   |                        |
 |  51936    |  x-euc-tw                 |                        |
 |  51949    |  EUC-KR                   |                        |
 |  52936    |  HZ-GB-2312               |                        |
 |  54936    |  GB18030                  |                        |
 |  65001    |  UTF-8                    |                        |
 +-----------+---------------------------+------------------------+
  
-----------Types
Return values

  NS_OK = 0;
  NS_ERROR_OUT_OF_MEMORY = $8007000e;

Returned types

  rCharsetInfo = record
  	Name: WideString;				// charset GNU canonical name
    CodePage: integer;			// MS Windows CodePage id
    Language: WideString;		// 
  end;

  rAboutHolder = record
    MajorVersionNr: Cardinal;	// Library's Major Version #
    MinorVersionNr: Cardinal;	// Library's Minor Version #
    BuildVersionNr: Cardinal;	// Library's Build/Release Version #
    About: WideString;        // Copyleft information; 
  end;

-----------Exported functions
  procedure chsdet_Reset; stdcall; 
  Reset Charset Detector state. Prepare to new analyse.
   
  function chsdet_HandleData(aBuf: pAnsiChar; aLen: integer): integer; stdcall; 
  Analyse given buffer.
  Parameters
  	aBuf - pointer to buffer with text.
		sLen - buffer length; 
  Return value 
  	NS_ERROR_OUT_OF_MEMORY - failure. Unable to create internal objects.
  	NS_OK - success.
  Note
  	Function can be called more that one time to continue guessing. Charset Detector 
	remember last state until chsdet_Reset called.
	 	
  function chsdet_Done: Boolean; stdcall; 
  Return value
    TRUE - Charset Detector is sure about text encoding.
    FALSE - Overwise.
  Note
  	If input buffer is smaller then 1K Charset Detector returns anyway FALSE.
	  	
  procedure chsdet_DataEnd; stdcall; 
  Signalise data end. If Charset Detector hasn't sure result (Done = FALSE) 
  the best guessed encoding will be set as result.
  
  function chsdet_GetDetectedCharset: rCharsetInfo; stdcall; 
  Returns guessed charset.

  function  chsdet_GetDetectedBOM: eBOMKind; stdcall; 
  Returns detected BOM.
	
  function  chsdet_GetBOMLength(BOM: eBOMKind): integer; stdcall; 
  Returns BOM's length.

  procedure chsdet_GetKnownCharsets(out KnownCharsets: WideString); 
  Fills the parameter with all supported charsets in form
  "CodePage - Name LineFeed".
  
  procedure chsdet_GetAbout(out About: rAboutHolder); stdcall; 
  Fills the parameter with version and copyleft information.
  		
-----------Usage sample
  The definition file can be found direcory 'bindings'
		- for Delphi/Pascal - "chsdet_dll_intf.pas"
		- for .NET - "chsDetIntf.cs"
	Simple applications located in directory 'tests'.
	
  Bellow is small usage sample in Delphi.
  
  // ws: WideString; // Wide string which can be used in Unicode controls.
  
  // Get encoding of some buffer
  chsdet_Reset;	
  chsdet_HandleData(aBuf, aLen);

  if not chsdet_Done then
    chsdet_DataEnd;

  chSInfo := chsdet_GetDetectedCharset();
  
  // convert buffer to WideString
  outputLength := MultiByteToWideChar(chSInfo.CodePage, 0, aBuf, aLen, nil, 0);
  SetLength(ws, outputLength);
  MultiByteToWideChar(chSInfo.CodePage, 0, aBuf, aLen, pWideChar(ws), outputLength);
  
  // If you using Unicode SynEdit
  SynEdit.Lines.Text := WS;
  
Nikolaj Yakowlew � 2006-2013 
