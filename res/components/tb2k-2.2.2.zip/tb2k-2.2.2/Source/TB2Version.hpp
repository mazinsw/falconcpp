// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Tb2version.pas' rev: 21.00

#ifndef Tb2versionHPP
#define Tb2versionHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Tb2version
{
//-- type declarations -------------------------------------------------------
typedef System::UnicodeString TToolbar2000Version;

//-- var, const, procedure ---------------------------------------------------
#define Toolbar2000Version L"2.2.2"
#define Toolbar2000VersionPropText L"Toolbar2000 version 2.2.2"

}	/* namespace Tb2version */
using namespace Tb2version;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Tb2versionHPP
