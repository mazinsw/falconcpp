This directory will be populated when the tb2k_dn10 package is compiled.
