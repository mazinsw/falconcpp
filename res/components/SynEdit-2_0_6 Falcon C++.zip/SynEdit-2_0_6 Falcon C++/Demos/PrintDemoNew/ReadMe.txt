PrintDemoNew.dpr
----------------

- Needs Delphi 5 or higher.
- Demonstrates the new component for printing and print preview.

