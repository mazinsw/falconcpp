This directory will be populated when the tb2k_d12 package is compiled.
